from rest_framework import generics
from rest_framework.response import Response
from .serializer import CustomerSerializer
from .models import Customer


class CustomerCreateApi(generics.CreateAPIView):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer

class CustomerApi(generics.ListAPIView):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer

class CustomerUpdateApi(generics.RetrieveUpdateAPIView):
    queryset=Customer.objects.all()
    serializer_class=CustomerSerializer

class CustomerDeleteApi(generics.RetrieveDestroyAPIView):
    queryset=Customer.objects.all()
    serializer_class=CustomerSerializer